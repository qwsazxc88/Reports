﻿using System;

namespace Reports.Core.Domain
{
    public class TerraGraphic : AbstractEntity
    {
        public virtual int UserId { get; set; }
        public virtual DateTime Day { get; set; }
        public virtual int Hours { get; set; }
        public virtual int PointId { get; set; }
        public virtual bool? IsCreditAvailable { get; set; }
    }
}