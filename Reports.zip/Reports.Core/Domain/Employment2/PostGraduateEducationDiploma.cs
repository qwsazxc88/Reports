﻿namespace Reports.Core.Domain
{
    public class PostGraduateEducationDiploma : AbstractEntityWithVersion
    {
        
    }
}
