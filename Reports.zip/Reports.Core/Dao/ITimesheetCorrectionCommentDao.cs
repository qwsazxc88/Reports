﻿using Reports.Core.Domain;

namespace Reports.Core.Dao
{
    public interface ITimesheetCorrectionCommentDao : IDao<TimesheetCorrectionComment>
    {
    }
}