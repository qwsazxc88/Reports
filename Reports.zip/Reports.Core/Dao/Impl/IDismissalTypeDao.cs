﻿using Reports.Core.Domain;

namespace Reports.Core.Dao.Impl
{
    public interface IDismissalTypeDao : IDao<DismissalType>
    {
    }
}