using System;
using System.Collections.Generic;
using System.Text;

namespace Reports.Core.Dao
{
	public interface IReportDao
	{
	}
}
