﻿using Reports.Core.Domain;

namespace Reports.Core.Dao
{
    public interface ITimesheetCorrectionTypeDao : IDao<TimesheetCorrectionType>
    {
    }
}