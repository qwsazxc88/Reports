﻿using Reports.Core.Domain;

namespace Reports.Core.Dao
{
    public interface IAccountDao : IDao<Account>
    {
    }
}