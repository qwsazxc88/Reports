﻿using Reports.Core.Domain;

namespace Reports.Core.Dao
{
    public interface IAbsenceTypeDao : IDao<AbsenceType>
    {
        //IList<AbsenceType> LoadAllSorted();
    }
}