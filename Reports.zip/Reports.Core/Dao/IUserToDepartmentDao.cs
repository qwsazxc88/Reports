﻿using System.Collections.Generic;
using Reports.Core.Domain;
using Reports.Core.Dto;

namespace Reports.Core.Dao
{
    /*public interface IUserToDepartmentDao : IDao<UserToDepartment>
    {
        IList<IdNameDto> GetByUserId(int userId);
    }*/
}