﻿insert into [dbo].[MissionReport]
(Version, CreateDate, EditDate, Number, AllSum, UserAllSum, UserSumReceived, AccountantAllSum, UserId, CreatorId, MissionOrderId)
values (1,Getdate(),Getdate(),1,12500,12500,12500,0,6456,6456,1)