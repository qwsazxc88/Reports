﻿set identity_insert dbo.Role  ON
insert into dbo.Role (Id, Version, Name) values (4096,1,N'Специалист по подбору персонала')
set identity_insert dbo.Role OFF