﻿set identity_insert [dbo].[AppointmentEducationType]  ON
insert into  [dbo].[AppointmentEducationType] (Id, Name) values (1,N'Фронт')
insert into  [dbo].[AppointmentEducationType] (Id, Name) values (2,N'БЭК')
set identity_insert  [dbo].[AppointmentEducationType] OFF