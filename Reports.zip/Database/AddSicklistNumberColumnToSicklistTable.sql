﻿ALTER TABLE  dbo.Sicklist add  [SicklistNumber] nvarchar(12) COLLATE Cyrillic_General_CI_AS NULL 
