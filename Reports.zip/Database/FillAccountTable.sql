﻿--70606810601002640201
--70606810901002640202
--60310810101000000034
--60310810401000000035
--60308810801111111111

insert into [dbo].[Account] (Number, IsDebitAccount) values (N'70606810601002640201',1)
insert into [dbo].[Account] (Number, IsDebitAccount) values (N'70606810901002640202',1)
insert into [dbo].[Account] (Number, IsDebitAccount) values (N'60310810101000000034',1)
insert into [dbo].[Account] (Number, IsDebitAccount) values (N'60310810401000000035',1)
insert into [dbo].[Account] (Number, IsDebitAccount) values (N'60308810801111111111',1)

-- 60308810801111111111
insert into [dbo].[Account] (Number, IsDebitAccount) values (N'60308810801111111111',0)
