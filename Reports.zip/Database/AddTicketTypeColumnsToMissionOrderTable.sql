﻿alter table dbo.MissionOrder add AirTicketType INT not null default 0
alter table dbo.MissionOrder add TrainTicketType INT not null default 0